# COVID-19 Vaccine Tracker

🇮🇳 Get email alerts when COVID-19 Vaccines are available in your city.

👉🏻 [Project Link](https://www.labnol.org/covid19-vaccine-tracker-210501)

[![Vaccine Tracker for India](./screenshot.png)](https://www.labnol.org/covid19-vaccine-tracker-210501)