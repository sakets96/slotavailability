export const footer = [
  '',
  'Developed by Amit Agarwal (digitalinspiration.com)',
  '--------',
  '',
].join('\n');
